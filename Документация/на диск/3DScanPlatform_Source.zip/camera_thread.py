# camera_thread.py

import cv2
import os
import numpy as np
from PyQt6.QtCore import QThread, pyqtSignal
from primesense import openni2

class CameraThread(QThread):
    finished = pyqtSignal()

    def __init__(self, depthToColor=False, sync=False, mirror=False, colormap=cv2.COLORMAP_JET, background=None):
        super().__init__()
        self.running = True
        self.depthToColor = depthToColor
        self.sync = sync
        self.mirror = mirror
        self.colormap = colormap
        self.background = background

        self.show_contour = False
        self.shift = (0, 0)
        self.stretch = (1.0, 1.0)

        self.latest_color = None
        self.latest_depth = None
        self.main_contour = None

    def set_show_contour(self, show: bool):
        self.show_contour = show

    def set_background(self, background_depth: np.ndarray):
        self.background = background_depth

    def set_shift_and_stretch(self, shift: tuple, stretch: tuple):
        self.shift = shift
        self.stretch = stretch

    def stop(self):
        self.running = False

    def save_frame(self, folder_path, rgb_filename, depth_filename):
        if self.latest_color is not None and self.latest_depth is not None:
            color_path = os.path.join(folder_path, rgb_filename)
            depth_path = os.path.join(folder_path, depth_filename)

            cv2.imwrite(color_path, self.latest_color)
            np.save(depth_path, self.latest_depth)

    def run(self):
        openni2.initialize()
        dev = openni2.Device.open_any()

        depth_stream = dev.create_depth_stream()
        color_stream = dev.create_color_stream()

        if self.sync:
            dev.set_depth_color_sync_enabled(True)
        if self.mirror:
            depth_stream.set_mirroring_enabled(True)
            color_stream.set_mirroring_enabled(True)

        depth_stream.start()
        color_stream.start()

        try:
            while self.running:
                depth_frame = depth_stream.read_frame()
                color_frame = color_stream.read_frame()

                depth_data = depth_frame.get_buffer_as_uint16()
                color_data = color_frame.get_buffer_as_uint8()

                depth = np.frombuffer(depth_data, dtype=np.uint16).reshape((480, 640))
                color = np.frombuffer(color_data, dtype=np.uint8).reshape((480, 640, 3))

                self.latest_depth = depth.copy()
                self.latest_color = cv2.cvtColor(color, cv2.COLOR_RGB2BGR)

                depth_filtered = cv2.medianBlur(self.latest_depth, 5)

                mask = None
                if self.background is not None:
                    mask = self._compute_foreground_mask(depth_filtered, self.background)

                color_adj = self._adjust_color(self.latest_color)

                if self.show_contour and mask is not None:
                    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                    if contours:
                        contours = sorted(contours, key=cv2.contourArea, reverse=True)
                        self.main_contour = contours[0]
                        cv2.drawContours(color_adj, [self.main_contour], -1, (0, 255, 0), 2)

                # Отображение
                cv2.imshow("RGB", color_adj)
                if mask is not None:
                    depth_colored = cv2.applyColorMap(
                        cv2.normalize(depth_filtered, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8),
                        self.colormap
                    )
                    if self.show_contour and self.main_contour is not None:
                        cv2.drawContours(depth_colored, [self.main_contour], -1, (0, 255, 0), 2)
                    cv2.imshow("Depth", depth_colored)

                if cv2.waitKey(1) == 27:
                    break

        finally:
            depth_stream.stop()
            color_stream.stop()
            openni2.unload()
            cv2.destroyAllWindows()
            self.finished.emit()

    def _compute_foreground_mask(self, current_depth, background_depth):
        kernel = np.ones((5, 5), np.uint8)
        diff = cv2.absdiff(current_depth, background_depth)
        _, thresh = cv2.threshold(diff, 50, 255, cv2.THRESH_BINARY)
        thresh = thresh.astype(np.uint8)
        thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
        thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
        return thresh

    def _adjust_color(self, color):
        shift_x, shift_y = self.shift
        stretch_x, stretch_y = self.stretch

        height, width = color.shape[:2]

        scaled = cv2.resize(color, (0, 0), fx=stretch_x, fy=stretch_y)

        M = np.float32([[1, 0, shift_x], [0, 1, shift_y]])
        shifted = cv2.warpAffine(scaled, M, (width, height))
        return shifted
