# td_viewer_thread.py

from PyQt6.QtCore import QThread, pyqtSignal
import open3d as o3d
import numpy as np
import time

class Open3DViewerThread(QThread):
    update_cloud_visibility = pyqtSignal(str, bool)

    def __init__(self, cloud_dict):
        super().__init__()
        self.cloud_dict = cloud_dict 
        self.visible_flags = {name: True for name in cloud_dict}
        self._running = True

    def run(self):
        self.vis = o3d.visualization.VisualizerWithKeyCallback()
        self.vis.create_window("3D Viewer")
        self.axis = o3d.geometry.TriangleMesh.create_coordinate_frame(size=0.05)
        self.vis.add_geometry(self.axis)

        for name, cloud in self.cloud_dict.items():
            if self.visible_flags[name]:
                self.vis.add_geometry(cloud)

        while self._running:
            for name, cloud in self.cloud_dict.items():
                if self.visible_flags[name]:
                    self.vis.update_geometry(cloud)
            self.vis.poll_events()
            self.vis.update_renderer()
            time.sleep(0.03)

        self.vis.destroy_window()

    def stop(self):
        self._running = False
        self.quit()
        self.wait()

    def set_visibility(self, name, visible):
        self.visible_flags[name] = visible
        if visible:
            self.vis.add_geometry(self.cloud_dict[name])
        else:
            self.vis.remove_geometry(self.cloud_dict[name], reset_bounding_box=False)
