# scanning_process_thread.py

import os
import socket
import struct
from PyQt6.QtCore import QThread, pyqtSignal


class ScanningThread(QThread):
    status_update = pyqtSignal(str)   
    finished = pyqtSignal()        
    aborted = pyqtSignal()          

    def __init__(self, camera_thread, platform_socket, folder, object_name, num_shots, angle, speed, acceleration):
        super().__init__()
        self.camera_thread = camera_thread
        self.socket = platform_socket
        self.folder = folder
        self.object_name = object_name
        self.num_shots = num_shots
        self.angle = angle
        self.speed = speed
        self.acceleration = acceleration
        self._abort_requested = False

    def run(self):
        try:
            # --- Сохраняем первый кадр
            self._save_frame(0)

            # --- Отправка команды "старт"
            self._send_scan_command(cmd=1)

            for shot_num in range(1, self.num_shots):
                if self._abort_requested:
                    self._send_abort_command()
                    return

                # --- Ждем ответ от микроконтроллера
                response = self._recv_exact(3)
                if not response or response[0] == 2:
                    self.status_update.emit("Scanning aborted by device.")
                    self.aborted.emit()
                    return

                turns_completed = int.from_bytes(response[1:3], byteorder='big')
                self.status_update.emit(f"Shots taken: {turns_completed}/{self.num_shots}")

                # --- Сохраняем следующий кадр
                self._save_frame(turns_completed)

                if shot_num < self.num_shots - 1:
                    # --- Команда "продолжить"
                    self._send_scan_command(cmd=2)

            # --- Получить финальный ответ
            response = self._recv_exact(3)
            if response and response[0] == 1:
                turns_completed = int.from_bytes(response[1:3], byteorder='big')
                self.status_update.emit(f"Scan complete: {turns_completed} shots taken.")

        except Exception as e:
            self.status_update.emit(f"Error during scanning: {e}")
        finally:
            self.finished.emit()

    def abort(self):
        self._abort_requested = True

    def _save_frame(self, shot_index):
        angle_val = shot_index * self.angle
        rgb_filename = f"{self.object_name}_rgb_{angle_val}.png"
        depth_filename = f"{self.object_name}_depth_{angle_val}.npy"
        self.camera_thread.save_frame(self.folder, rgb_filename, depth_filename)

    def _send_scan_command(self, cmd):
        # cmd: 1 = старт, 2 = продолжить
        payload = bytearray(65)
        payload[0] = cmd
        payload[1:3] = self.num_shots.to_bytes(2, 'big')
        payload[17:19] = self.angle.to_bytes(2, 'big')
        payload[33:35] = self.speed.to_bytes(2, 'big')
        payload[49:51] = self.acceleration.to_bytes(2, 'big')
        self.socket.sendall(payload)

    def _send_abort_command(self):
        payload = bytearray(65)
        payload[0] = 3  # команда "прервать"
        self.socket.sendall(payload)
        response = self._recv_exact(3)
        if response and response[0] == 2:
            self.status_update.emit("Scan aborted.")
            self.aborted.emit()

    def _recv_exact(self, num_bytes):
        data = bytearray()
        while len(data) < num_bytes:
            chunk = self.socket.recv(num_bytes - len(data))
            if not chunk:
                break
            data.extend(chunk)
        return data
