# main_gui.py

import sys
import json
import os
import time
import socket
import cv2
import re
import numpy as np
import open3d as o3d

import importlib.util

from PyQt6.QtWidgets import QApplication, QMainWindow, QFileDialog, QTableWidgetItem, QCheckBox, QWidget, QHBoxLayout, QLineEdit, QMessageBox
from PyQt6.QtCore import Qt

from mainwindow import Ui_MainWindow
from camera_thread import CameraThread
from scanning_process_thread import ScanningThread
from td_viewer_thread import Open3DViewerThread

class MyForm(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self) 

        self.CONFIG_FILE = "config.json"

        # ---- Переменные для подключения ---- 
        self.platform_connected = False
        self.platform_socket = None

        # ---- Для работы с камерой ----
        self.camera_thread = None

        # ---- Для процесса сканирования ----
        self.scanning_process_thread = None

        # ---- Для 3d визуализации ----
        self.td_visualiser_thread = None

        # ---- Инициализация полей ---- 
        self.set_default_platform_tab()
        self.set_default_cam_check_tab()
        self.set_default_scanning_tab()
        self.set_default_framesprocessing_tab()
        self.set_default_cloudsprocessing_tab()

        # ---- Настройка сигналов и связей ----
        self.set_connections_platform_tab()
        self.set_connections_cam_check_tab()
        self.set_connections_scanning_tab()
        self.set_connections_framesprocessing_tab()
        self.set_connections_cloudsprocessing_tab()

    # Загрузка конфигов
    def load_config(self):
        if os.path.exists(self.CONFIG_FILE):
            with open(self.CONFIG_FILE, "r") as f:
                return json.load(f)
        return {}

    # ---- Platform tab init ----
    def set_default_platform_tab(self):
        config = self.load_config().get("platform_tab", {})
        self.platformConnectionSettings_platformPort_lineEdit.setText(config.get("platformPort", "1234"))
        self.platformConnectionSettings_platformIP_lineEdit.setText(config.get("platformIP", "1.1.1.1"))
        self.platformConnectionSettings_ApSSID_lineEdit.setText(config.get("ApSSID", "network name"))
        self.platformConnectionSettings_APPAssword_lineEdit.setText(config.get("APPAssword", "11111111"))
        self.platformConnectionSettings_APPAssword_lineEdit.setEchoMode(QLineEdit.EchoMode.Password)
        
    def set_connections_platform_tab(self):
        self.platformConnectionSettings_connect_pushButton_2.clicked.connect(self.sendNewAPData)
        self.platformConnectionSettings_connect_pushButton.clicked.connect(self.connect_disconnect_button_process)

    # ---- Cam check init ----
    def set_default_cam_check_tab(self):
        self.cameraCheck_cameraOutput_checkBox.setChecked(False)
        
        self.cameraCheck_depthToColor_checkBox.setChecked(True)
        self.cameraCheck_syncIsEnabled_checkBox.setChecked(True)
        self.cameraCheck_mirroringIsEnables_checkBox.setChecked(True)
        
        self.cameraCheck_resolutionX_spinBox.setMinimum(1)
        self.cameraCheck_resolutionX_spinBox.setMaximum(640)
        self.cameraCheck_resolutionX_spinBox.setSingleStep(1)
        self.cameraCheck_resolutionX_spinBox.setValue(640)
        
        self.cameraCheck_resolutionY_spinBox.setMinimum(1)
        self.cameraCheck_resolutionY_spinBox.setMaximum(480)
        self.cameraCheck_resolutionY_spinBox.setSingleStep(1)
        self.cameraCheck_resolutionY_spinBox.setValue(480)

        self.cameraCheck_depthDisplayMethod_comboBox.clear()
        colormaps = [
            ("Colormap Jet", cv2.COLORMAP_JET),
            ("Colormap Bone", cv2.COLORMAP_BONE),
            ("Colormap Plasma", cv2.COLORMAP_PLASMA)
        ]
        for name, value in colormaps:
            self.cameraCheck_depthDisplayMethod_comboBox.addItem(name, userData=value)

    def set_connections_cam_check_tab(self):
        self.cameraCheck_cameraOutput_checkBox.stateChanged.connect(self.cam_check_camera_outp_on_off)
        self.cameraCheck_chooseFolder_pushButton.clicked.connect(self.choose_folder)
        self.cameraCheck_makePhoto_pushButton.clicked.connect(self.make_photo)

    # ---- Scanning tab init ----
    def set_default_scanning_tab(self):
        config = self.load_config().get("scanning_tab", {})

        self.scanningSettings_speed_spinBox.setMinimum(1)
        self.scanningSettings_speed_spinBox.setMaximum(60)
        self.scanningSettings_speed_spinBox.setSingleStep(1)
        self.scanningSettings_speed_spinBox.setValue(config.get("speed", 10))

        self.scanningSettings_acceeration_spinBox.setMinimum(1)
        self.scanningSettings_acceeration_spinBox.setMaximum(20)
        self.scanningSettings_acceeration_spinBox.setSingleStep(1)
        self.scanningSettings_acceeration_spinBox.setValue(config.get("acceleration", 3))

        self.scanningSettings_numverOfShots_spinBox.setMinimum(1)
        self.scanningSettings_numverOfShots_spinBox.setMaximum(1000)  # условный максимум
        self.scanningSettings_numverOfShots_spinBox.setSingleStep(1)
        self.scanningSettings_numverOfShots_spinBox.setValue(config.get("numberOfShots", 18))

        self.scanningSettings_rotationAngle_spinBox.setMinimum(1)
        self.scanningSettings_rotationAngle_spinBox.setMaximum(360)
        self.scanningSettings_rotationAngle_spinBox.setSingleStep(1)
        self.scanningSettings_rotationAngle_spinBox.setValue(config.get("rotationAngle", 20))

    def set_connections_scanning_tab(self):
        self.scanningSettings_showCamOutput_checkBox.stateChanged.connect(self.cam_check_camera_outp_on_off)
        self.scanningSettings_chooseFolder_pushButton.clicked.connect(self.choose_folder)
        self.scanningSettings_start_pushButton_2.clicked.connect(self.save_background)
        self.scanningSettings_start_pushButton.clicked.connect(self.scanning_process)

    # ---- Frames processing tab init ----
    def set_default_framesprocessing_tab(self):
        self.framesProcessing_depthCameraIntrinsics_width_doubleSpinBox.setValue(640.0)
        self.framesProcessing_depthCameraIntrinsics_heigth_doubleSpinBox.setValue(480.0)
        self.framesProcessing_depthCameraIntrinsics_fx_doubleSpinBox.setValue(554.26)
        self.framesProcessing_depthCameraIntrinsics_fy_doubleSpinBox.setValue(579.41)
        self.framesProcessing_depthCameraIntrinsics_cx_doubleSpinBox.setValue(320.0)
        self.framesProcessing_depthCameraIntrinsics_cy_doubleSpinBox.setValue(240.0)

        self.framesProcessing_RGBCameraIntrinsics_width_doubleSpinBox.setValue(640.0)
        self.framesProcessing_RGBCameraIntrinsics_height_doubleSpinBox.setValue(480.0)
        self.framesProcessing_RGBCameraIntrinsics_fx_doubleSpinBox.setValue(515.23)
        self.framesProcessing_RGBCameraIntrinsics_fy_doubleSpinBox.setValue(534.06)
        self.framesProcessing_RGBCameraIntrinsics_cx_doubleSpinBox.setValue(320.0)
        self.framesProcessing_RGBCameraIntrinsics_cy_doubleSpinBox.setValue(240.0)

        self.framesProcessing_depthCameraIntrinsics_checkBox.setChecked(True)

        self.framesProcessing_morphKernelSize_doubleSpinBox.setValue(5)

    def set_connections_framesprocessing_tab(self):
        self.framesProcessing_folder_pushButton.clicked.connect(self.choose_folder)
        self.framesProcessing_videoMode_checkBox.stateChanged.connect(self.frameProc_Set_camOutpMode)
        self.framesProcessing_onOffImage_checkBox.stateChanged.connect(self.frame_proc_on_off_cam)
        self.framesProcessing_showCountour_checkBox.stateChanged.connect(self.frameProc_Set_contourOutpMode)
        self.framesProcessing_folderToSave_pushButton.clicked.connect(self.get_clouds_save_dir)
        self.framesProcessing_apply_pushButton.clicked.connect(self.get_clouds_from_frames)

        self.framesProcessing_shiftX_doubleSpinBox.valueChanged.connect(self.frameProc_ManAdjustment)
        self.framesProcessing_shiftY_doubleSpinBox.valueChanged.connect(self.frameProc_ManAdjustment)
        self.framesProcessing_stretchX_doubleSpinBox.valueChanged.connect(self.frameProc_ManAdjustment)
        self.framesProcessing_stretchY_doubleSpinBox.valueChanged.connect(self.frameProc_ManAdjustment)

    # ---- Clouds processing tab init ----
    def set_default_cloudsprocessing_tab(self):
        config = self.load_config().get("cloudsProcessing_tab", {})

        def init_combobox(widget, items, default):
            widget.clear()
            for name in items:
                widget.addItem(name, userData=name)
            index = widget.findData(config.get(widget.objectName(), default))
            if index != -1:
                widget.setCurrentIndex(index)
            else:
                widget.setCurrentIndex(0)

        self.cloudsProcessing_uploadFiltration_checkBox.setChecked(config.get("cloudsProcessing_uploadFiltration", True))
        self.cloudsProcessing_filtrationNeighbors_doubleSpinBox.setRange(20, 100)
        self.cloudsProcessing_filtrationNeighbors_doubleSpinBox.setValue(config.get("cloudsProcessing_filtrationNeighbors", 40))
        self.cloudsProcessing_outlierSensitivity_doubleSpinBox.setRange(0.5, 2.0)
        self.cloudsProcessing_outlierSensitivity_doubleSpinBox.setValue(config.get("cloudsProcessing_outlierSensitivity", 1.0))
        self.cloudsProcessing_enableDistanceFilter_checkBox.setChecked(config.get("cloudsProcessing_enableDistanceFilter", True))
        self.cloudsProcessing_uploadFilterMaxDistance_doubleSpinBox.setRange(0.6, 8.0)
        self.cloudsProcessing_uploadFilterMaxDistance_doubleSpinBox.setValue(config.get("cloudsProcessing_uploadFilterMaxDistance", 0.6))
        self.cloudsProcessing_uploadFilterMinDistance_doubleSpinBox.setRange(0.6, 8.0)
        self.cloudsProcessing_uploadFilterMinDistance_doubleSpinBox.setValue(config.get("cloudsProcessing_uploadFilterMinDistance", 8.0))
        self.cloudsProcessing_preloadShift_checkBox.setChecked(config.get("cloudsProcessing_preloadShift", False))

        init_combobox(self.cloudsProcessing_downsamplingMode_comboBox, ["fixed", "adaptive"], "fixed")

        self.cloudsProcessing_downsampling_vovelSize_doubleSpinBox.setRange(0.001, 0.1)
        self.cloudsProcessing_downsampling_vovelSize_doubleSpinBox.setValue(config.get("cloudsProcessing_downsampling_vovelSize", 0.002))
        self.cloudsProcessing_downsamplingMinPointsPerVoxel_doubleSpinBox.setRange(1, 20)
        self.cloudsProcessing_downsamplingMinPointsPerVoxel_doubleSpinBox.setValue(config.get("cloudsProcessing_downsamplingMinPntsPerVoxel", 5))

        self.cloudsProcessing_normalsCalculation_checkBox.setChecked(config.get("cloudsProcessing_normalsCalculation", True))
        self.cloudsProcessing_normalEstimationRadius_doubleSpinBox.setRange(1.0, 10.0)
        self.cloudsProcessing_normalEstimationRadius_doubleSpinBox.setValue(config.get("cloudsProcessing_normalEstimationRadius", 2.0))

        self.cloudsProcessing_globalRegistrationIsEnabled_checkBox.setChecked(config.get("cloudsProcessing_globalRegistrationIsEnabled", True))
        self.cloudsProcessing_featureRadiusMultipliers_lineEdit.setText(config.get("cloudsProcessing_featureRadiusMultipliers", "x3.0, x5.0, x8.0"))
        init_combobox(self.cloudsProcessing_aligmentMethod_comboBox, ["RANSAC", "FGR", "HYBRID"], "RANSAC")
        self.cloudsProcessing_ransacMaxIterations_doubleSpinBox.setRange(10, 5000)
        self.cloudsProcessing_ransacMaxIterations_doubleSpinBox.setValue(config.get("cloudsProcessing_ransacMaxIterations", 1000))
        self.cloudsProcessing_ransacConfidenceLevel_doubleSpinBox.setRange(0.8, 0.999)
        self.cloudsProcessing_ransacConfidenceLevel_doubleSpinBox.setValue(config.get("cloudsProcessing_ransacConfidenceLevel", 0.999))
        self.cloudsProcessing_ransacRandomSamples_doubleSpinBox.setRange(5, 20)
        self.cloudsProcessing_ransacRandomSamples_doubleSpinBox.setValue(config.get("cloudsProcessing_ransacRandomSamples", 7))
        self.cloudsProcessing_fgrMaxIterations_doubleSpinBox.setRange(30, 200)
        self.cloudsProcessing_fgrMaxIterations_doubleSpinBox.setValue(config.get("cloudsProcessing_fgrMaxIterations", 64))
        self.cloudsProcessing_fgrDivisionFactor_doubleSpinBox.setRange(1.2, 4.0)
        self.cloudsProcessing_fgrDivisionFactor_doubleSpinBox.setValue(config.get("cloudsProcessing_fgrDivisionFactor", 1.4))

        self.cloudsProcessing_edgeLengthVerificationCheck_checkBox.setChecked(config.get("cloudsProcessing_edgeLengthVerificationCheck", True))
        self.cloudsProcessing_distanceVerificationCheck_checkBox.setChecked(config.get("cloudsProcessing_distanceVerificationCheck", False))
        self.cloudsProcessing_normalsVerificationCheck_checkBox.setChecked(config.get("cloudsProcessing_normalsVerificationCheck", False))

        init_combobox(self.cloudsProcessing_icpMethod_comboBox, ["P2Point", "P2Plane"], "P2Plane")

        self.cloudsProcessing_useCoarseIcpRegistration_checkBox.setChecked(config.get("cloudsProcessing_useCoarseIcpRegistration", True))
        self.cloudsProcessing_coarseIcpMaxIterations_doubleSpinBox.setRange(30, 100)
        self.cloudsProcessing_coarseIcpMaxIterations_doubleSpinBox.setValue(config.get("cloudsProcessing_coarseIcpMaxIterations", 60))
        self.cloudsProcessing_useAbsoluteValues_checkBox_2.setChecked(config.get("cloudsProcessing_useAbsoluteValues_coarse", True))
        self.cloudsProcessing_coarseThresholdAbsolute_doubleSpinBox.setRange(1, 50)
        self.cloudsProcessing_coarseThresholdAbsolute_doubleSpinBox.setValue(config.get("cloudsProcessing_coarseThresholdAbsolute", 1))
        self.cloudsProcessing_coarseThresholdMultiplier_doubleSpinBox.setRange(3.0, 6.0)
        self.cloudsProcessing_coarseThresholdMultiplier_doubleSpinBox.setValue(config.get("cloudsProcessing_coarseThresholdMultiplier", 3.0))
        self.cloudsProcessing_coarseIcpRelativeFitness_doubleSpinBox.setRange(0.1, 1.0)
        self.cloudsProcessing_coarseIcpRelativeFitness_doubleSpinBox.setValue(config.get("cloudsProcessing_coarseIcpRelativeFitness", 0.4))
        self.cloudsProcessing_coarseIcpRelativeRmse_doubleSpinBox.setRange(1, 40)
        self.cloudsProcessing_coarseIcpRelativeRmse_doubleSpinBox.setValue(config.get("cloudsProcessing_coarseIcpRelativeRmse", 5))

        self.cloudsProcessing_useFineIcpRegistration_checkBox.setChecked(config.get("cloudsProcessing_useFineIcpRegistration", True))
        self.cloudsProcessing_fineIcpMaxIterations_doubleSpinBox.setRange(20, 50)
        self.cloudsProcessing_fineIcpMaxIterations_doubleSpinBox.setValue(config.get("cloudsProcessing_fineIcpMaxIterations", 30))
        self.cloudsProcessing_useAbsoluteValues_checkBox.setChecked(config.get("cloudsProcessing_useAbsoluteValues", True))
        self.cloudsProcessing_coarseThresholdAbsolute_doubleSpinBox_2.setRange(0.1, 5.0)
        self.cloudsProcessing_coarseThresholdAbsolute_doubleSpinBox_2.setValue(config.get("cloudsProcessing_fineThresholdAbsolute", 0.5))
        self.cloudsProcessing_coarseThresholdMultiplier_doubleSpinBox.setRange(1, 5)
        self.cloudsProcessing_coarseThresholdMultiplier_doubleSpinBox.setValue(config.get("cloudsProcessing_coarseThresholdMultiplier", 1))
        self.cloudsProcessing_fineIcpRelativeFitness_doubleSpinBox.setRange(0.5, 1.0)
        self.cloudsProcessing_fineIcpRelativeFitness_doubleSpinBox.setValue(config.get("cloudsProcessing_fineIcpRelativeFitness", 0.9))
        self.cloudsProcessing_fineIcpRelativeRmse_doubleSpinBox.setRange(0.5, 3.0)
        self.cloudsProcessing_fineIcpRelativeRmse_doubleSpinBox.setValue(config.get("cloudsProcessing_fineIcpRelativeRmse", 1.0))

        self.cloudsProcessing_useColorIcp_checkBox.setChecked(config.get("cloudsProcessing_useColorIcp", True))
        self.cloudsProcessing_shapeImportance_doubleSpinBox.setRange(0.5, 1.0)
        self.cloudsProcessing_shapeImportance_doubleSpinBox.setValue(config.get("cloudsProcessing_shapeImportance", 0.9))
        self.cloudsProcessing_colorImportance_doubleSpinBox.setRange(0.0, 0.5)
        self.cloudsProcessing_colorImportance_doubleSpinBox.setValue(config.get("cloudsProcessing_colorImportance", 0.1))

        self.cloudsProcessing_postprocessingVoxelSize_doubleSpinBox.setRange(0.0, 4.0)
        self.cloudsProcessing_postprocessingVoxelSize_doubleSpinBox.setValue(config.get("cloudsProcessing_postprocessingVoxelSize", 1.0))
        self.cloudsProcessing_fillHoles_checkBox.setChecked(config.get("cloudsProcessing_fillHoles", True))
        self.cloudsProcessing_postprocessingHoleSize_doubleSpinBox.setRange(0.01, 0.1)
        self.cloudsProcessing_postprocessingHoleSize_doubleSpinBox.setValue(config.get("cloudsProcessing_postprocessingHoleSize", 0.05))
        self.cloudsProcessing_filtering_checkBox.setChecked(config.get("cloudsProcessing_filtering", True))
        self.cloudsProcessing_minArtifactSize_doubleSpinBox.setRange(100, 500)
        self.cloudsProcessing_minArtifactSize_doubleSpinBox.setValue(config.get("cloudsProcessing_minArtifactSize", 100))
        self.cloudsProcessing_filteringArtifactSensitivity_doubleSpinBox.setRange(0.01, 0.05)
        self.cloudsProcessing_filteringArtifactSensitivity_doubleSpinBox.setValue(config.get("cloudsProcessing_filtrArtifactSensitivity", 0.02))
        self.cloudsProcessing_keepLargest_checkBox.setChecked(config.get("cloudsProcessing_keepLargest", True))

        init_combobox(self.cloudsProcessing_smoothingMethod_comboBox, ["none", "mls", "laplasian"], "none")
        self.cloudsProcessing_smoothingRadius_doubleSpinBox.setRange(0.01, 0.05)
        self.cloudsProcessing_smoothingRadius_doubleSpinBox.setValue(config.get("cloudsProcessing_smoothingRadius", 0.03))
        self.cloudsProcessing_smoothingIterations_doubleSpinBox.setRange(1, 5)
        self.cloudsProcessing_smoothingIterations_doubleSpinBox.setValue(config.get("cloudsProcessing_smoothingIterations", 2))
        self.cloudsProcessing_edgePreserve_checkBox.setChecked(config.get("cloudsProcessing_edgePreserve", True))
        self.cloudsProcessing_smoothingTaubinLambda_doubleSpinBox.setRange(0.1, 0.5)
        self.cloudsProcessing_smoothingTaubinLambda_doubleSpinBox.setValue(config.get("cloudsProcessing_smoothingTaubinLambda", 0.3))
        self.cloudsProcessing_smoothingTaubinMu_doubleSpinBox.setRange(-0.5, 0.0)
        self.cloudsProcessing_smoothingTaubinMu_doubleSpinBox.setValue(config.get("cloudsProcessing_smoothingTaubinMu", -0.3))

        self.cloudsProcessing_optimization_checkBox.setChecked(config.get("cloudsProcessing_optimization", True))
        init_combobox(self.cloudsProcessing_optimizationAlgorithm_comboBox, ["L-M", "G_N", "Levenberg"], "L-M")
        self.cloudsProcessing_useLoopClosure_checkBox.setChecked(config.get("cloudsProcessing_useLoopClosure", True))
        self.cloudsProcessing_minOverlapPoints_doubleSpinBox.setRange(100, 1000)
        self.cloudsProcessing_minOverlapPoints_doubleSpinBox.setValue(config.get("cloudsProcessing_minOverlapPoints", 500))
        self.cloudsProcessing_edgePruneThreshold_doubleSpinBox.setRange(0.1, 0.5)
        self.cloudsProcessing_edgePruneThreshold_doubleSpinBox.setValue(config.get("cloudsProcessing_edgePruneThreshold", 0.25))
        self.cloudsProcessing_useGeodesic_checkBox.setChecked(config.get("cloudsProcessing_useGeodesic", True))

        self.cloudsProcessing_exportReconstructionMethod_comboBox.clear()
        self.cloudsProcessing_exportReconstructionMethod_comboBox.addItems([
            "Ball-Pivot", "Poisson", "Alpha-Shapes", "Delaunay"
        ])
        self.cloudsProcessing_exportReconstructionMethod_comboBox.setCurrentText("Poisson")

        self.cloudsProcessing_exportMeshResolution_comboBox.clear()
        self.cloudsProcessing_exportMeshResolution_comboBox.addItems([
            "Low", "Average", "High"
        ])
        self.cloudsProcessing_exportMeshResolution_comboBox.setCurrentText("Average")

        self.cloudsProcessing_exportFinalSmoothing_comboBox.clear()
        self.cloudsProcessing_exportFinalSmoothing_comboBox.addItems([
            "None", "Laplacian", "Taubin"
        ])
        self.cloudsProcessing_exportFinalSmoothing_comboBox.setCurrentText("None")

    def set_connections_cloudsprocessing_tab(self):
        self.cloudsProcessing_open3dSpace_pushButton.clicked.connect(self.open_3d_space)
        self.cloudsProcessing_chooseFilesNUpload_pushButton.clicked.connect(self.choose_n_upload_clouds)
        self.cloudsProcessing_applyNProcess_pushButton.clicked.connect(self.merge_clouds)
        self.cloudsProcessing_saveResult_pushButton.clicked.connect(self.save_cloud)

        self.cloudsProcessing_manualAdjustmentShiftX_horizontalSlider.valueChanged.connect(self.manual_position_correction)
        self.cloudsProcessing_manualAdjustmentShiftY_horizontalSlider.valueChanged.connect(self.manual_position_correction)
        self.cloudsProcessing_manualAdjustmentShiftZ_horizontalSlider.valueChanged.connect(self.manual_position_correction)
        self.cloudsProcessing_manualAdjustmentRotShiftXY_horizontalSlider.valueChanged.connect(self.manual_position_correction)
        self.cloudsProcessing_manualAdjustmentRotShiftXZ_horizontalSlider.valueChanged.connect(self.manual_position_correction)
        self.cloudsProcessing_manualAdjustmentRotShiftYZ_horizontalSlider.valueChanged.connect(self.manual_position_correction)

        self.cloudsProcessing_manualAdjustmentIsEnabled_checkBox.toggled.connect(self.set_manual_correction_mode)

    def save_platform_tab(self, config):
        config["platform_tab"] = {
            "platformPort": self.platformConnectionSettings_platformPort_lineEdit.text(),
            "platformIP": self.platformConnectionSettings_platformIP_lineEdit.text(),
            "ApSSID": self.platformConnectionSettings_ApSSID_lineEdit.text(),
            "APPAssword": self.platformConnectionSettings_APPAssword_lineEdit.text()
        }

    # def save_cam_check_tab(self, config):
    #     pass

    def save_scanning_tab(self, config):
        config["scanning_tab"] = {
            "speed": self.scanningSettings_speed_spinBox.value(),
            "acceleration": self.scanningSettings_acceeration_spinBox.value(),
            "numberOfShots": self.scanningSettings_numverOfShots_spinBox.value(),
            "rotationAngle": self.scanningSettings_rotationAngle_spinBox.value()
        }

    # def save_framesprocessing_tab(self, config):
    #     pass

    def save_cloudsprocessing_tab(self, config):
        config["cloudsprocessing_tab"] = {
            "uploadFiltration_checkBox": self.cloudsProcessing_uploadFiltration_checkBox.isChecked(),
            "filtrationNeighbors_spinBox": self.cloudsProcessing_filtrationNeighbors_doubleSpinBox.value(),
            "outlierSensitivity_doubleSpinBox": self.cloudsProcessing_outlierSensitivity_doubleSpinBox.value(),
            "enableDistanceFilter_checkBox": self.cloudsProcessing_enableDistanceFilter_checkBox.isChecked(),
            "uploadFilterMaxDistance_doubleSpinBox": self.cloudsProcessing_uploadFilterMaxDistance_doubleSpinBox.value(),
            "uploadFilterMinDistance_doubleSpinBox": self.cloudsProcessing_uploadFilterMinDistance_doubleSpinBox.value(),
            "preloadShift_checkBox": self.cloudsProcessing_preloadShift_checkBox.isChecked(),

            "downsamplingMode_comboBox": self.cloudsProcessing_downsamplingMode_comboBox.currentText(),
            "downsampling_vovelSize_doubleSpinBox": self.cloudsProcessing_downsampling_vovelSize_doubleSpinBox.value(),
            "downsamplingMinPntsPerVoxel_spinBox": self.cloudsProcessing_downsamplingMinPointsPerVoxel_doubleSpinBox.value(),
            "normalsCalculation_checkBox": self.cloudsProcessing_normalsCalculation_checkBox.isChecked(),
            "normalEstimationRadius_doubleSpinBox": self.cloudsProcessing_normalEstimationRadius_doubleSpinBox.value(),

            "globalRegistrationIsEnabled_checkBox": self.cloudsProcessing_globalRegistrationIsEnabled_checkBox.isChecked(),
            "featureRadiusMultipliers_lineEdit": self.cloudsProcessing_featureRadiusMultipliers_lineEdit.text(),
            "aligmentMethod_comboBox": self.cloudsProcessing_aligmentMethod_comboBox.currentText(),
            "ransacMaxIterations_spinBox": self.cloudsProcessing_ransacMaxIterations_doubleSpinBox.value(),
            "ransacConfidenceLevel_doubleSpinBox": self.cloudsProcessing_ransacConfidenceLevel_doubleSpinBox.value(),
            "ransacRandomSamples_spinBox": self.cloudsProcessing_ransacRandomSamples_doubleSpinBox.value(),
            "fgrMaxIterations_spinBox": self.cloudsProcessing_fgrMaxIterations_spinBox.value(),
            "fgrDivisionFactor_doubleSpinBox": self.cloudsProcessing_fgrDivisionFactor_doubleSpinBox.value(),
            "edgeLengthVerificationCheck_checkBox": self.cloudsProcessing_edgeLengthVerificationCheck_checkBox.isChecked(),
            "distanceVerificationCheck_checkBox": self.cloudsProcessing_distanceVerificationCheck_checkBox.isChecked(),
            "normalsVerificationCheck_checkBox": self.cloudsProcessing_normalsVerificationCheck_checkBox.isChecked(),

            "icpMethod_comboBox": self.cloudsProcessing_icpMethod_comboBox.currentText(),
            "useCoarseIcpRegistration_checkBox": self.cloudsProcessing_useCoarseIcpRegistration_checkBox.isChecked(),
            "coarseIcpMaxIterations_spinBox": self.cloudsProcessing_coarseIcpMaxIterations_spinBox.value(),
            "useAbsoluteValues_coarse_checkBox": self.cloudsProcessing_useAbsoluteValues_checkBox_2.isChecked(),
            "coarseThresholdAbsolute_spinBox": self.cloudsProcessing_coarseThresholdAbsolute_spinBox.value(),
            "coarseThresholdMultiplier_doubleSpinBox": self.cloudsProcessing_coarseThresholdMultiplier_doubleSpinBox.value(),
            "coarseIcpRelativeFitness_doubleSpinBox": self.cloudsProcessing_coarseIcpRelativeFitness_doubleSpinBox.value(),
            "coarseIcpRelativeRmse_spinBox": self.cloudsProcessing_coarseIcpRelativeRmse_spinBox.value(),
            "useFineIcpRegistration_checkBox": self.cloudsProcessing_useFineIcpRegistration_checkBox.isChecked(),
            "fineIcpMaxIterations_spinBox": self.cloudsProcessing_fineIcpMaxIterations_spinBox.value(),
            "useAbsoluteValues_checkBox": self.cloudsProcessing_useAbsoluteValues_checkBox.isChecked(),
            "fineThresholdAbsolute_doubleSpinBox": self.cloudsProcessing_fineThresholdAbsolute_doubleSpinBox.value(),
            "coarseThresholdMultiplier_spinBox": self.cloudsProcessing_coarseThresholdMultiplier_spinBox.value(),
            "fineIcpRelativeFitness_doubleSpinBox": self.cloudsProcessing_fineIcpRelativeFitness_doubleSpinBox.value(),
            "fineIcpRelativeRmse_doubleSpinBox": self.cloudsProcessing_fineIcpRelativeRmse_doubleSpinBox.value(),
            "useColorIcp_checkBox": self.cloudsProcessing_useColorIcp_checkBox.isChecked(),
            "shapeImportance_doubleSpinBox": self.cloudsProcessing_shapeImportance_doubleSpinBox.value(),
            "colorImportance_doubleSpinBox": self.cloudsProcessing_colorImportance_doubleSpinBox.value(),
            
            "postprocessingVoxelSize_doubleSpinBox": self.cloudsProcessing_postprocessingVoxelSize_doubleSpinBox.value(),
            "fillHoles_checkBox": self.cloudsProcessing_fillHoles_checkBox.isChecked(),
            "postprocessingHoleSize_doubleSpinBox": self.cloudsProcessing_postprocessingHoleSize_doubleSpinBox.value(),
            "filtering_checkBox": self.cloudsProcessing_filtering_checkBox.isChecked(),
            "minArtifactSize_spinBox": self.cloudsProcessing_minArtifactSize_spinBox.value(),
            "filtrArtifactSensitivity_doubleSpinBox": self.cloudsProcessing_filtrArtifactSensitivity_doubleSpinBox.value(),
            "keepLargest_checkBox": self.cloudsProcessing_keepLargest_checkBox.isChecked(),
            "smoothingMethod_comboBox": self.cloudsProcessing_smoothingMethod_comboBox.currentText(),
            "smoothingRadius_doubleSpinBox": self.cloudsProcessing_smoothingRadius_doubleSpinBox.value(),
            "smoothingIterations_doubleSpinBox": self.cloudsProcessing_smoothingIterations_doubleSpinBox.value(),
            "edgePreserve_checkBox": self.cloudsProcessing_edgePreserve_checkBox.isChecked(),
            "smoothingTaubinLambda_doubleSpinBox": self.cloudsProcessing_smoothingTaubinLambda_doubleSpinBox.value(),
            "smoothingTaubinMu_doubleSpinBox": self.cloudsProcessing_smoothingTaubinMu_doubleSpinBox.value(),
            "optimization_checkBox": self.cloudsProcessing_optimization_checkBox.isChecked(),
            "optimizationAlgorithm_comboBox": self.cloudsProcessing_optimizationAlgorithm_comboBox.currentText(),
            "useLoopClosure_checkBox": self.cloudsProcessing_useLoopClosure_checkBox.isChecked(),
            "minOverlapPoints_spinBox": self.cloudsProcessing_minOverlapPoints_spinBox.value(),
            "edgePruneThreshold_doubleSpinBox": self.cloudsProcessing_edgePruneThreshold_doubleSpinBox.value(),
            "useGeodesic_checkBox": self.cloudsProcessing_useGeodesic_checkBox.isChecked(),

            "exportReconstructionMethod_comboBox": self.cloudsProcessing_exportReconstructionMethod_comboBox.currentText(),
            "exportMeshResolution_comboBox": self.cloudsProcessing_exportMeshResolution_comboBox.currentText(),
            "exportFinalSmoothing_comboBox": self.cloudsProcessing_exportFinalSmoothing_comboBox.currentText()
        }

    # Обработка закрытия    
    def closeEvent(self, event):
        config = self.load_config()
        # self.save_platform_tab(config)
        self.save_cam_check_tab(config)
        self.save_scanning_tab(config)
        self.save_framesprocessing_tab(config)
        self.save_cloudsprocessing_tab(config)
        self.save_config(config)
        event.accept()

    def save_config(self, config):
        with open(self.CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=4)

    def connect_disconnect_button_process(self):
        if not self.platform_connected:
            ip = self.platformConnectionSettings_platformIP_lineEdit.text().strip()
            port_str = self.platformConnectionSettings_platformPort_lineEdit.text().strip()

            # Проверка IP
            try:
                socket.inet_aton(ip)
            except socket.error:
                QMessageBox.critical(self, "Error", "Invalid IP address")
                return

            # Проверка порта
            try:
                port = int(port_str)
                if not (0 <= port <= 65535):
                    raise ValueError
            except ValueError:
                QMessageBox.critical(self, "Error", "Port must be a number between 0 and 65535")
                return

            # Попытка подключения
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(3)
                s.connect((ip, port))
                response = s.recv(1024).decode(errors="ignore").strip()

                if "Добро пожаловать" in response:
                    self.platform_connected = True
                    self.platform_socket = s
                    self.platformConnectionSettings_connect_disconnect_pushButton.setText("disconnect")
                    self.platformConnectionSettings_platformStatus_label.setText("Platform Status: is Connected")
                else:
                    s.close()
                    QMessageBox.warning(self, "Error", "No confirmation message received from platform")
            except Exception as e:
                QMessageBox.critical(self, "Connection Error", str(e))
        else:
            # Отправка сигнала отключения
            try:
                disconnect_packet = bytearray(65)
                disconnect_packet[0] = 5
                self.platform_socket.sendall(disconnect_packet)
                self.platform_socket.close()
            except Exception as e:
                QMessageBox.warning(self, "Warning", f"Disconnection error: {e}")
            finally:
                self.platform_connected = False
                self.platform_socket = None
                self.platformConnectionSettings_connect_disconnect_pushButton.setText("connect")
                self.platformConnectionSettings_platformStatus_label.setText("Platform Status: is Disconnected")

    def sendNewAPData(self):
        # Проверка подключения
        if not self.platform_connected or self.platform_socket is None:
            QMessageBox.warning(self, "Error", "Connect to the platform first")
            return

        ssid = self.platformConnectionSettings_ApSSID_lineEdit.text().strip().encode('utf-8')
        password = self.platformConnectionSettings_APPAssword_lineEdit.text().strip().encode('utf-8')

        # Проверка наличия данных
        if not ssid or not password:
            QMessageBox.warning(self, "Error", "SSID and password must not be empty")
            return

        try:
            # Формирование пакета
            packet = bytearray(65)
            packet[0] = 4  # Команда установить параметры сети
            packet[1:1 + min(len(ssid), 32)] = ssid[:32]
            packet[33:33 + min(len(password), 32)] = password[:32]

            self.platform_socket.sendall(packet)

            # Ожидание ответа
            response = self.platform_socket.recv(3)
            if len(response) == 3 and response[0] == 3:
                QMessageBox.information(self, "Success", "Network parameters sent successfully")
            else:
                QMessageBox.warning(self, "Error", "Invalid response from platform")
        except Exception as e:
            QMessageBox.critical(self, "Send Error", str(e))
            return

        time.sleep(1)
        try:
            self.platform_socket.sendall(b'\x00')  # ping
            self.platform_socket.recv(1)
        except:
            self.platform_connected = False
            self.platform_socket.close()
            self.platform_socket = None
            self.platformConnectionSettings_connect_disconnect_pushButton.setText("connect")
            self.platformConnectionSettings_platformStatus_label.setText("Platform Status: is Disconnected")

    def cam_check_camera_outp_on_off(self):
        if self.camera_thread and self.camera_thread.isRunning():
            self.camera_thread.stop()
            self.camera_thread.wait()
            self.camera_thread = None
        else:
            depthToColor = self.cameraCheck_depthToColor_checkBox.isChecked()
            sync = self.cameraCheck_syncIsEnabled_checkBox.isChecked()
            mirror = self.cameraCheck_mirroringIsEnables_checkBox.isChecked()
            colormap = self.cameraCheck_depthDisplayMethod_comboBox.currentData()

            self.camera_thread = CameraThread(depthToColor, sync, mirror, colormap)
            self.camera_thread.finished.connect(self.on_camera_thread_finished)
            self.camera_thread.start()

    def on_camera_thread_finished(self):
        self.camera_thread = None

    def choose_folder(self):
        dir_path = QFileDialog.getExistingDirectory(self, "Select Directory", "")
        if dir_path:
            self.cameraCheck_chooseFolder_lineEdit.setText(dir_path)
            self.scanningSettings_chooseFolder_lineEdit.setText(dir_path)
            self.framesProcessing_folder_lineEdit.setText(dir_path)

    def make_photo(self):
        folder = self.cameraCheck_chooseFolder_lineEdit.text().strip()
        name = self.cameraCheck_photoName_lineEdit.text().strip()

        if not folder or not name:
            QMessageBox.warning(self, "Missing Information", "Please specify folder and photo name.")
            return

        if not os.path.exists(folder):
            QMessageBox.warning(self, "Invalid Folder", "The specified folder does not exist.")
            return

        if not self.camera_thread or not self.camera_thread.isRunning():
            QMessageBox.warning(self, "Camera Not Running", "Camera must be running to take a photo.")
            return

        try:
            rgb_filename = f"rgb_{name}.png"
            depth_filename = f"depth_{name}.npy"
            self.camera_thread.save_frame(folder, rgb_filename, depth_filename)
            QMessageBox.information(self, "Success", f"Photo '{name}' saved in:\n{folder}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save photo:\n{e}")

    def save_background(self):
        name = self.scanningSettings_objectName_lineEdit.text().strip()

        if not name:
            QMessageBox.warning(self, "Warning", "Object name is empty.")
            return

        folder = self.scanningSettings_chooseFolder_lineEdit.text().strip()

        if not folder:
            QMessageBox.warning(self, "Warning", "No folder selected for saving.")
            return

        if not os.path.exists(folder):
            QMessageBox.critical(self, "Error", "Selected folder does not exist.")
            return

        if hasattr(self, "camera_thread") and self.camera_thread.isRunning():
            rgb_filename = f"{name}_rgb_background.png"
            depth_filename = f"{name}_depth_background.npy"
            try:
                self.camera_thread.save_frame(folder, rgb_filename, depth_filename)
                QMessageBox.information(self, "Saved", f"Background saved:\n{rgb_filename}\n{depth_filename}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save background:\n{e}")
        else:
            QMessageBox.critical(self, "Error", "Camera is not running.")

    def scanning_process(self):
        if self.scanning_process_thread and self.scanning_process_thread.isRunning():
            # Если поток сканирования активен, прервать его
            self.statusBar().showMessage("Aborting scan...")
            self.scanning_process_thread.abort()
            return

        # --- Проверка обязательных условий ---
        folder = self.scanningSettings_chooseFolder_lineEdit.text().strip()
        object_name = self.scanningSettings_objectName_lineEdit.text().strip()

        if not os.path.exists(folder):
            QMessageBox.critical(self, "Error", "Folder does not exist.")
            return

        if not object_name:
            QMessageBox.warning(self, "Warning", "Object name is empty.")
            return

        if not hasattr(self, "camera_thread") or not self.camera_thread.isRunning():
            QMessageBox.critical(self, "Error", "Camera is not running.")
            return

        if not hasattr(self, "platform_socket"):
            QMessageBox.critical(self, "Error", "Platform is not connected.")
            return

        try:
            num_shots = self.scanningSettings_numverOfShots_spinBox.value()
            angle = self.scanningSettings_rotationAngle_spinBox.value()
            speed = self.scanningSettings_speed_spinBox.value()
            acceleration = self.scanningSettings_acceeration_spinBox.value()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to read scan settings: {e}")
            return

        # --- Создание и запуск потока сканирования ---
        self.scanning_process_thread = ScanningThread(
            camera_thread=self.camera_thread,
            platform_socket=self.platform_socket,
            folder=folder,
            object_name=object_name,
            num_shots=num_shots,
            angle=angle,
            speed=speed,
            acceleration=acceleration
        )

        self.scanning_process_thread.status_update.connect(self.statusBar().showMessage)
        self.scanning_process_thread.finished.connect(self.scanning_finished)
        self.scanning_process_thread.aborted.connect(self.scanning_aborted)

        self.scanning_process_thread.start()
        self.scanningSettings_start_pushButton.setText("Abort")
        self.statusBar().showMessage("Scanning started...")

    def scanning_finished(self):
        self.statusBar().showMessage("Scanning finished.")
        self.scanningSettings_start_pushButton.setText("Start")
        self.scanning_process_thread = None

    def scanning_aborted(self):
        self.statusBar().showMessage("Scanning aborted.")
        self.scanningSettings_start_pushButton.setText("Start")
        self.scanning_process_thread = None

    def get_clouds_save_dir(self):
        dir_path = QFileDialog.getExistingDirectory(self, "Select Directory", "")
        if dir_path:
            self.framesProcessing_folderToSave_lineEdit.setText(dir_path)

    def frameProc_Set_camOutpMode(self):
        if self.ui.framesProcessing_videoMode_checkBox.isChecked():
            # Работа в режиме камеры
            if not hasattr(self, "cameraThread") or self.cameraThread is None:
                self.cameraThread = CameraThread()
            self.cameraThread.start()
        else:
            # Загрузка из файлов
            folder = self.ui.framesProcessing_folder_pushButton.text()
            obj_name = self.ui.framesProcessing_objectName_lineEdit.text()
            angle = self.ui.framesProcessing_photoReferenceAngle_doubleSpinBox.value()

            rgb_path = os.path.join(folder, f"{obj_name}_rgb_{int(angle)}.png")
            depth_path = os.path.join(folder, f"{obj_name}_depth_{int(angle)}.npy")
            bg_path = os.path.join(folder, f"{obj_name}_depth_background.npy")

            if os.path.exists(rgb_path) and os.path.exists(depth_path) and os.path.exists(bg_path):
                rgb = cv2.imread(rgb_path)
                depth = np.load(depth_path)
                bg = np.load(bg_path)

                self.cameraThread = CameraThread(background=bg)
                self.cameraThread.latest_color = rgb
                self.cameraThread.latest_depth = depth
                self.cameraThread.start()

    def frame_proc_on_off_cam(self):
        enabled = self.ui.framesProcessing_onOffImage_checkBox.isChecked()
        if self.cameraThread:
            self.cameraThread.running = enabled
            if enabled and not self.cameraThread.isRunning():
                self.cameraThread.start()
            elif not enabled:
                self.cameraThread.stop()

    def frameProc_Set_contourOutpMode(self):
        if self.cameraThread:
            show = self.ui.framesProcessing_showCountour_checkBox.isChecked()
            self.cameraThread.set_show_contour(show)

    def frameProc_ManAdjustment(self):
        if not hasattr(self, "cameraThread") or self.cameraThread is None:
            return
        shift_x = self.ui.framesProcessing_shiftX_doubleSpinBox.value()
        shift_y = self.ui.framesProcessing_shiftY_doubleSpinBox.value()
        stretch_x = self.ui.framesProcessing_stretchX_doubleSpinBox.value()
        stretch_y = self.ui.framesProcessing_stretchY_doubleSpinBox.value()

        self.cameraThread.set_shift_and_stretch((shift_x, shift_y), (stretch_x, stretch_y))

    def rgb_shift_n_rotate(self, color_bgr):
        shift_x = self.framesProcessing_shiftX_doubleSpinBox.value()
        shift_y = self.framesProcessing_shiftY_doubleSpinBox.value()
        stretch_x = self.framesProcessing_stretchX_doubleSpinBox.value()
        stretch_y = self.framesProcessing_stretchY_doubleSpinBox.value()
        h, w = color_bgr.shape[:2]

        scaled = cv2.resize(color_bgr, (0, 0), fx=stretch_x, fy=stretch_y)

        canvas = np.zeros_like(color_bgr)
        shx = int(shift_x)
        shy = int(shift_y)
        src_y, src_x = scaled.shape[:2]

        x1 = max(0, shx)
        y1 = max(0, shy)
        x2 = min(w, shx + src_x)
        y2 = min(h, shy + src_y)

        xs = max(0, -shx)
        ys = max(0, -shy)
        xe = xs + (x2 - x1)
        ye = ys + (y2 - y1)

        canvas[y1:y2, x1:x2] = scaled[ys:ye, xs:xe]
        return canvas

    def load_user_rgbd_proc_function(self, filepath):
        # загрузка пользовательской функции
        spec = importlib.util.spec_from_file_location("user_module", filepath)
        user_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(user_module)
        user_func = getattr(user_module, "custom_rgbd_images_process", None)
        return user_func

    def apply_user_rgbd_proc_function(self, func, depth_list, angles_list, color_list):
        if func is None:
            return []
        return func(depth_list, color_list, angles_list)

    def get_clouds_from_frames(self):
        object_name = self.framesProcessing_objectName_lineEdit.text()
        folder = self.framesProcessing_folder_lineEdit.text()
        save_folder = self.framesProcessing_folderToSave_lineEdit.text()
        os.makedirs(save_folder, exist_ok=True)

        use_custom = self.framesProcessing_useCustomProcessing_checkBox.isChecked()
        depth_trunc = self.framesProcessing_depthTrunc_doubleSpinBox.value()
        morph_size = int(self.framesProcessing_morphKernelSize_doubleSpinBox.value())
        num_to_show = int(self.framesProcessing_numberOfClouds_doubleSpinBox.value())

        # интринсики
        if self.framesProcessing_depthCameraIntrins_checkBox.isChecked():
            width = int(self.framesProcessing_depthCameraIntrinsics_width_doubleSpinBox.value())
            height = int(self.framesProcessing_depthCameraIntrinsics_heigth_doubleSpinBox.value())
            fx = self.framesProcessing_depthCameraIntrinsics_fx_doubleSpinBox.value()
            fy = self.framesProcessing_depthCameraIntrinsics_fy_doubleSpinBox.value()
            cx = self.framesProcessing_depthCameraIntrinsics_cx_doubleSpinBox.value()
            cy = self.framesProcessing_depthCameraIntrinsics_cy_doubleSpinBox.value()
            intrinsic = o3d.camera.PinholeCameraIntrinsic(width, height, fx, fy, cx, cy)
        else:
            intrinsic = o3d.camera.PinholeCameraIntrinsic()  # дефолт

        background_path = os.path.join(folder, f"{object_name}_depth_background.npy")
        background = np.load(background_path)

        angles = []
        color_list = []
        depth_list = []
        clouds = []

        for file in os.listdir(folder):
            if file.startswith(f"{object_name}_depth_") and file.endswith(".npy") and "background" not in file:
                angle = file.split("_")[-1].replace(".npy", "")
                angles.append(angle)

        for angle in angles:
            color_path = os.path.join(folder, f"{object_name}_rgb_{angle}.png")
            depth_path = os.path.join(folder, f"{object_name}_depth_{angle}.npy")

            if not (os.path.exists(color_path) and os.path.exists(depth_path)):
                continue

            color_bgr = cv2.imread(color_path)
            depth_raw = np.load(depth_path)

            color_bgr = self.rgb_shift_n_rotate(color_bgr)

            if use_custom:
                color_list.append(color_bgr)
                depth_list.append(depth_raw)
            else:
                depth_filtered = cv2.medianBlur(depth_raw, morph_size)
                depth_diff = cv2.absdiff(depth_filtered, background)
                _, depth_thresh = cv2.threshold(depth_diff, 50, 255, cv2.THRESH_BINARY)
                depth_thresh = depth_thresh.astype(np.uint8)

                kernel = np.ones((morph_size, morph_size), np.uint8)
                depth_thresh = cv2.morphologyEx(depth_thresh, cv2.MORPH_OPEN, kernel)
                depth_thresh = cv2.morphologyEx(depth_thresh, cv2.MORPH_CLOSE, kernel)

                contours, _ = cv2.findContours(depth_thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                if not contours:
                    continue

                main_contour = max(contours, key=cv2.contourArea)
                mask = np.zeros_like(depth_thresh)
                cv2.drawContours(mask, [main_contour], -1, 255, thickness=-1)
                mask_bool = mask.astype(bool)

                depth_masked = np.zeros_like(depth_raw)
                depth_masked[mask_bool] = depth_filtered[mask_bool]

                color_bgr_masked = np.zeros_like(color_bgr)
                color_bgr_masked[mask_bool] = color_bgr[mask_bool]

                color_rgb = cv2.cvtColor(color_bgr_masked, cv2.COLOR_BGR2RGB)
                color_o3d = o3d.geometry.Image(color_rgb)
                depth_o3d = o3d.geometry.Image(depth_masked)

                rgbd = o3d.geometry.RGBDImage.create_from_color_and_depth(
                    color_o3d, depth_o3d, depth_scale=1000.0, depth_trunc=depth_trunc, convert_rgb_to_intensity=False
                )

                pcd = o3d.geometry.PointCloud.create_from_rgbd_image(rgbd, intrinsic)
                clouds.append((angle, pcd))

        if use_custom:
            user_path = self.framesProcessing_useCustomProcessing_lineEdit.text()
            user_func = self.load_user_rgbd_proc_function(user_path)
            angles_uint8 = np.array([int(a) for a in angles], dtype=np.uint8)
            pcd_list = self.apply_user_rgbd_proc_function(user_func, depth_list, angles_uint8, color_list)
            for angle, pcd in zip(angles, pcd_list):
                clouds.append((angle, pcd))

        for i, (angle, cloud) in enumerate(clouds):
            save_path = os.path.join(save_folder, f"{object_name}_cloud_{angle}.ply")
            o3d.io.write_point_cloud(save_path, cloud)
            if i < num_to_show:
                o3d.visualization.draw_geometries([cloud])

    def choose_n_upload_clouds(self):
        file_paths, _ = QFileDialog.getOpenFileNames(self, "Select Point Clouds", "", "PLY Files (*.ply)")
        if not file_paths:
            return

        pattern = re.compile(r"(.+?)_(\d+)\.ply$")
        for path in file_paths:
            filename = os.path.basename(path)
            match = pattern.match(filename)
            if not match:
                continue

            object_name, angle_str = match.groups()
            angle = float(angle_str)
            cloud_name = f"{object_name}_{angle_str}"

            try:
                print(f"\nЗагрузка {filename}...")
                cloud = o3d.io.read_point_cloud(path)

                if not cloud.has_points():
                    raise ValueError(f"Облако {path} пустое!")

                if self.cloudsProcessing_uploadFiltration_checkBox.isChecked():
                    nb_neighbors = int(self.cloudsProcessing_filtrationNeighbors_doubleSpinBox.value())
                    std_ratio = float(self.cloudsProcessing_outlierSensitivity_doubleSpinBox.value())
                    cloud, ind = cloud.remove_statistical_outlier(nb_neighbors=nb_neighbors, std_ratio=std_ratio)
                    cloud = cloud.select_by_index(ind)

                    if self.cloudsProcessing_enableDistanceFilter_checkBox.isChecked():
                        min_d = float(self.cloudsProcessing_uploadFilterMinDistance_doubleSpinBox.value())
                        max_d = float(self.cloudsProcessing_uploadFilterMaxDistance_doubleSpinBox.value())
                        distances = np.asarray(cloud.points)[:, 2]
                        indices = np.where((distances >= min_d) & (distances <= max_d))[0]
                        cloud = cloud.select_by_index(indices)

                if self.cloudsProcessing_preloadShift_checkBox.isChecked():
                    shift_x = float(self.cloudsProcessing_preloadAxisShiftX_doubleSpinBox.value())
                    shift_y = float(self.cloudsProcessing_preloadAxisShiftY_doubleSpinBox.value())
                    shift_z = float(self.cloudsProcessing_preloadAxisShiftZ_doubleSpinBox.value())
                    rot_xy = float(self.cloudsProcessing_preloadRotationShiftXY_doubleSpinBox.value())
                    rot_xz = float(self.cloudsProcessing_preloadRotationShiftXZ_doubleSpinBox.value())
                    rot_yz = float(self.cloudsProcessing_preloadRotationShiftYZ_doubleSpinBox.value())

                    shift = np.eye(4)
                    shift[:3, 3] = [shift_x, shift_y, shift_z]
                    cloud.transform(shift)

                    if rot_xy != 0:
                        Rz = o3d.geometry.get_rotation_matrix_from_axis_angle([0, 0, np.radians(rot_xy)])
                        cloud.rotate(Rz, center=(0, 0, 0))
                    if rot_xz != 0:
                        Ry = o3d.geometry.get_rotation_matrix_from_axis_angle([0, np.radians(rot_xz), 0])
                        cloud.rotate(Ry, center=(0, 0, 0))
                    if rot_yz != 0:
                        Rx = o3d.geometry.get_rotation_matrix_from_axis_angle([np.radians(rot_yz), 0, 0])
                        cloud.rotate(Rx, center=(0, 0, 0))

                if angle != 0:
                    rotation_matrix = o3d.geometry.get_rotation_matrix_from_axis_angle([0, 0, np.radians(angle)])
                    cloud.rotate(rotation_matrix, center=(0, 0, 0))

                if not hasattr(self, "clouds"):
                    self.clouds = {}
                self.clouds[cloud_name] = cloud

                self.add_cloud_row(cloud_name)

            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to load {filename}:\n{str(e)}")

    def add_cloud_row(self, cloud_name: str):
        table = self.cloudsProcessing_cloudsList_tableWidget
        row_position = table.rowCount()
        table.insertRow(row_position)

        show_widget = QWidget()
        show_checkbox = QCheckBox()
        layout_show = QHBoxLayout(show_widget)
        layout_show.addWidget(show_checkbox)
        layout_show.setContentsMargins(0, 0, 0, 0)
        layout_show.setAlignment(show_checkbox, Qt.AlignmentFlag.AlignCenter)
        table.setCellWidget(row_position, 0, show_widget)

        merge_widget = QWidget()
        merge_checkbox = QCheckBox()
        layout_merge = QHBoxLayout(merge_widget)
        layout_merge.addWidget(merge_checkbox)
        layout_merge.setContentsMargins(0, 0, 0, 0)
        layout_merge.setAlignment(merge_checkbox, Qt.AlignmentFlag.AlignCenter)
        table.setCellWidget(row_position, 1, merge_widget)

        item = QTableWidgetItem(cloud_name)
        #item.setFlags(item.flags() ^ Qt.ItemFlag.ItemIsEditable)  # только для чтения
        table.setItem(row_position, 2, item)

    def open_3d_space(self):
        if hasattr(self, 'viewer_thread') and self.viewer_thread.isRunning():
            return  # уже запущен

        table = self.cloudsProcessing_cloudsList_tableWidget
        cloud_dict = {}
        for row in range(table.rowCount()):
            cloud_name = table.item(row, 2).text()
            cloud = self.loaded_clouds.get(cloud_name)
            if cloud is not None:
                cloud_dict[cloud_name] = cloud

        self.viewer_thread = Open3DViewerThread(cloud_dict)
        self.viewer_thread.start()

        for row in range(table.rowCount()):
            show_widget = table.cellWidget(row, 0)
            if show_widget:
                checkbox = show_widget.findChild(QCheckBox)
                cloud_name = table.item(row, 2).text()

                def handler(state, name=cloud_name):
                    visible = state == Qt.CheckState.Checked
                    self.viewer_thread.set_visibility(name, visible)

                checkbox.stateChanged.connect(handler)

    def set_manual_correction_mode(self, enabled: bool):
        self.cloudsProcessing_manualAdjustmentShiftX_horizontalSlider.setEnabled(enabled)
        self.cloudsProcessing_manualAdjustmentShiftY_horizontalSlider.setEnabled(enabled)
        self.cloudsProcessing_manualAdjustmentShiftZ_horizontalSlider.setEnabled(enabled)
        self.cloudsProcessing_manualAdjustmentRotShiftXY_horizontalSlider.setEnabled(enabled)
        self.cloudsProcessing_manualAdjustmentRotShiftXZ_horizontalSlider.setEnabled(enabled)
        self.cloudsProcessing_manualAdjustmentRotShiftYZ_horizontalSlider.setEnabled(enabled)

    def manual_position_correction(self):
        table = self.cloudsProcessing_cloudsList_tableWidget
        row = table.currentRow()
        if row < 0:
            return

        cloud_name = table.item(row, 2).text()
        cloud = self.loaded_clouds.get(cloud_name)
        if cloud is None:
            return

        dx = self.cloudsProcessing_manualAdjustmentShiftX_horizontalSlider.value() / 1000.0
        dy = self.cloudsProcessing_manualAdjustmentShiftY_horizontalSlider.value() / 1000.0
        dz = self.cloudsProcessing_manualAdjustmentShiftZ_horizontalSlider.value() / 1000.0
        rxy = self.cloudsProcessing_manualAdjustmentRotShiftXY_horizontalSlider.value()
        rxz = self.cloudsProcessing_manualAdjustmentRotShiftXZ_horizontalSlider.value()
        ryz = self.cloudsProcessing_manualAdjustmentRotShiftYZ_horizontalSlider.value()

        transform = np.eye(4)
        transform[:3, 3] = [dx, dy, dz]
        cloud.transform(transform)

        def rotate(cloud, axis, degrees):
            radians = np.deg2rad(degrees)
            R = np.eye(4)
            if axis == 'x':
                R[1:3, 1:3] = [[np.cos(radians), -np.sin(radians)],
                            [np.sin(radians),  np.cos(radians)]]
            elif axis == 'y':
                R[[0, 0, 2, 2], [0, 2, 0, 2]] = [np.cos(radians), np.sin(radians),
                                                -np.sin(radians), np.cos(radians)]
            elif axis == 'z':
                R[0:2, 0:2] = [[np.cos(radians), -np.sin(radians)],
                            [np.sin(radians),  np.cos(radians)]]
            cloud.transform(R)

        rotate(cloud, 'z', rxy)
        rotate(cloud, 'x', rxz)
        rotate(cloud, 'y', ryz)

        if hasattr(self, 'viewer_thread') and self.viewer_thread.isRunning():
            self.viewer_thread.vis.update_geometry(cloud)

    def merge_clouds(self):
        def log(msg):
            self.cloudsProcessing_log_textBrowser.append(msg)

        def parse_radius_multipliers(text):
            return [float(m.group(1)) for m in re.finditer(r"x([\d.]+)", text)]

        def preprocess_cloud(pcd, voxel_size):
            pcd = pcd.voxel_down_sample(voxel_size)
            if self.cloudsProcessing_normalsCalculation_checkBox.isChecked():
                radius = self.cloudsProcessing_normalEstimationRadius_doubleSpinBox.value()
                pcd.estimate_normals(search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=radius, max_nn=30))
            return pcd

        def run_ransac(source, target, radius):
            source_fpfh = o3d.pipelines.registration.compute_fpfh_feature(
                source, o3d.geometry.KDTreeSearchParamHybrid(radius=radius, max_nn=100))
            target_fpfh = o3d.pipelines.registration.compute_fpfh_feature(
                target, o3d.geometry.KDTreeSearchParamHybrid(radius=radius, max_nn=100))
            checkers = []
            if self.cloudsProcessing_edgeLengthVerificationCheck_checkBox.isChecked():
                checkers.append(o3d.pipelines.registration.CorrespondenceCheckerBasedOnEdgeLength(0.9))
            if self.cloudsProcessing_distanceVerificationCheck_checkBox.isChecked():
                checkers.append(o3d.pipelines.registration.CorrespondenceCheckerBasedOnDistance(radius))
            if self.cloudsProcessing_normalsVerificationCheck_checkBox.isChecked():
                checkers.append(o3d.pipelines.registration.CorrespondenceCheckerBasedOnNormal(0.5235988))
            return o3d.pipelines.registration.registration_ransac_based_on_feature_matching(
                source, target, source_fpfh, target_fpfh, radius,
                o3d.pipelines.registration.TransformationEstimationPointToPoint(False),
                4, checkers,
                o3d.pipelines.registration.RANSACConvergenceCriteria(
                    int(self.cloudsProcessing_ransacMaxIterations_doubleSpinBox.value()),
                    int(self.cloudsProcessing_ransacRandomSamples_doubleSpinBox.value()))
            )

        def run_fgr(source, target, radius):
            source_fpfh = o3d.pipelines.registration.compute_fpfh_feature(
                source, o3d.geometry.KDTreeSearchParamHybrid(radius=radius, max_nn=100))
            target_fpfh = o3d.pipelines.registration.compute_fpfh_feature(
                target, o3d.geometry.KDTreeSearchParamHybrid(radius=radius, max_nn=100))
            option = o3d.pipelines.registration.FastGlobalRegistrationOption(
                maximum_correspondence_distance=radius,
                maximum_iterations=int(self.cloudsProcessing_fgrMaxIterations_doubleSpinBox.value()),
                division_factor=self.cloudsProcessing_fgrDivisionFactor_doubleSpinBox.value()
            )
            return o3d.pipelines.registration.registration_fgr_based_on_feature_matching(
                source, target, source_fpfh, target_fpfh, option)

        def global_register(source, target, voxel_size, radii, method):
            best_result = None
            for r in radii:
                feature_radius = voxel_size * r
                if method == "ransac":
                    result = run_ransac(source, target, feature_radius)
                elif method == "fgr":
                    result = run_fgr(source, target, feature_radius)
                else:
                    ransac_result = run_ransac(source, target, feature_radius)
                    fgr_result = run_fgr(source, target, feature_radius)
                    result = max([ransac_result, fgr_result], key=lambda r: r.fitness)
                if best_result is None or result.fitness > best_result.fitness:
                    best_result = result
            return best_result

        def apply_icp(source, target, init_trans, voxel_size):
            current = init_trans
            if self.cloudsProcessing_useCoarseIcpRegistration_checkBox.isChecked():
                max_iter = int(self.cloudsProcessing_coarseIcpMaxIterations_doubleSpinBox.value())
                rel_fitness = self.cloudsProcessing_coarseIcpRelativeFitness_doubleSpinBox.value()
                rel_rmse = self.cloudsProcessing_coarseIcpRelativeRmse_doubleSpinBox.value()
                threshold = self.cloudsProcessing_coarseThresholdAbsolute_doubleSpinBox.value() if \
                    self.cloudsProcessing_useAbsoluteValues_checkBox_2.isChecked() else \
                    voxel_size * self.cloudsProcessing_coarseThresholdMultiplier_doubleSpinBox.value()
                icp = o3d.pipelines.registration.registration_icp(
                    source, target, threshold, current,
                    o3d.pipelines.registration.TransformationEstimationPointToPlane(),
                    o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=max_iter,
                                                                    relative_fitness=rel_fitness,
                                                                    relative_rmse=rel_rmse))
                current = icp.transformation
            if self.cloudsProcessing_useFineIcpRegistration_checkBox.isChecked():
                max_iter = int(self.cloudsProcessing_fineIcpMaxIterations_doubleSpinBox.value())
                rel_fitness = self.cloudsProcessing_fineIcpRelativeFitness_doubleSpinBox.value()
                rel_rmse = self.cloudsProcessing_fineIcpRelativeRmse_doubleSpinBox.value()
                threshold = self.cloudsProcessing_coarseThresholdAbsolute_doubleSpinBox_2.value() if \
                    self.cloudsProcessing_useAbsoluteValues_checkBox.isChecked() else \
                    voxel_size * self.cloudsProcessing_coarseThresholdMultiplier_doubleSpinBox.value()
                icp = o3d.pipelines.registration.registration_icp(
                    source, target, threshold, current,
                    o3d.pipelines.registration.TransformationEstimationPointToPlane(),
                    o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=max_iter,
                                                                    relative_fitness=rel_fitness,
                                                                    relative_rmse=rel_rmse))
                current = icp.transformation
            return current

        def fill_holes(cloud):
            if not self.cloudsProcessing_fillHoles_checkBox.isChecked():
                return cloud
            try:
                mesh, _ = o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(cloud, depth=9)
                mesh = mesh.crop(cloud.get_axis_aligned_bounding_box())
                return mesh.sample_points_poisson_disk(len(cloud.points))
            except:
                return cloud

        def filter_artifacts(cloud):
            if not self.cloudsProcessing_filtering_checkBox.isChecked():
                return cloud
            cl, _ = cloud.remove_statistical_outlier(
                nb_neighbors=20,
                std_ratio=self.cloudsProcessing_filteringArtifactSensitivity_doubleSpinBox.value())
            return cl

        def smooth_cloud(cloud):
            if self.cloudsProcessing_smoothingMethod_comboBox.currentText() == "None":
                return cloud
            try:
                cloud.estimate_normals()
                mesh = o3d.geometry.TriangleMesh.create_from_point_cloud_alpha_shape(cloud, 0.02)
                mesh = mesh.filter_smooth_taubin(
                    number_of_iterations=int(self.cloudsProcessing_smoothingIterations_doubleSpinBox.value()),
                    lambda_param=self.cloudsProcessing_smoothingTaubinLambda_doubleSpinBox.value(),
                    mu=self.cloudsProcessing_smoothingTaubinMu_doubleSpinBox.value())
                return mesh.sample_points_poisson_disk(number_of_points=len(cloud.points))
            except:
                return cloud

        log("=== Starting point cloud merging ===")

        voxel_size = self.cloudsProcessing_downsampling_vovelSize_doubleSpinBox.value()
        radii = parse_radius_multipliers(self.cloudsProcessing_featureRadiusMultipliers_lineEdit.text())
        method = self.cloudsProcessing_aligmentMethod_comboBox.currentText().lower()

        rows = self.clouds_tableWidget.rowCount()
        clouds_to_merge = []
        angles = []
        for i in range(rows):
            item = self.clouds_tableWidget.item(i, 1)
            if item.checkState():
                cloud = self.loaded_clouds[i]
                clouds_to_merge.append((i, cloud))
                angles.append(str(self.clouds_tableWidget.item(i, 2).text()))

        if len(clouds_to_merge) < 2:
            log("Not enough clouds to merge.")
            return

        base_idx, merged = clouds_to_merge[0]
        merged = preprocess_cloud(merged, voxel_size)

        for i in range(1, len(clouds_to_merge)):
            idx, next_cloud = clouds_to_merge[i]
            next_pre = preprocess_cloud(next_cloud, voxel_size)
            log(f"Registering cloud {idx} to merged cloud...")
            result = global_register(next_pre, merged, voxel_size, radii, method)
            log(f"Global registration: fitness={result.fitness:.4f}")
            transformation = apply_icp(next_pre, merged, result.transformation, voxel_size)
            next_cloud.transform(transformation)
            merged += next_cloud
            merged = preprocess_cloud(merged, voxel_size)

        log("Post-processing...")
        merged = fill_holes(merged)
        merged = filter_artifacts(merged)
        merged = smooth_cloud(merged)

        name = f"{self.object_name}_cloud_{','.join(angles)}.ply"
        merged_path = f"./merged_clouds/{name}"
        o3d.io.write_point_cloud(merged_path, merged)

        row = self.clouds_tableWidget.rowCount()
        self.clouds_tableWidget.insertRow(row)
        self.clouds_tableWidget.setItem(row, 0, QTableWidgetItem(name))
        new_checkbox = QTableWidgetItem()
        new_checkbox.setCheckState(Qt.Unchecked)
        self.clouds_tableWidget.setItem(row, 1, new_checkbox)
        self.clouds_tableWidget.setItem(row, 2, QTableWidgetItem("Merged"))
        self.loaded_clouds.append(merged)

        for idx, _ in clouds_to_merge:
            self.clouds_tableWidget.setRowHidden(idx, True)

        log("Merging complete.")
        self.display_merged_cloud(merged)

    def save_cloud(self):
        dir_path = QFileDialog.getExistingDirectory(self, "Select Directory", "")
        if not dir_path:
            self.cloudsProcessing_log_textBrowser.append("Save cancelled: no directory selected.")
            return

        selected_rows = self.clouds_tableWidget.selectionModel().selectedRows()
        if len(selected_rows) != 1:
            self.cloudsProcessing_log_textBrowser.append("Error: please select exactly one cloud.")
            return
        row = selected_rows[0].row()
        cloud = self.loaded_clouds[row]

        method = self.cloudsProcessing_exportReconstructionMethod_comboBox.currentText().lower()
        resolution = self.cloudsProcessing_exportMeshResolution_comboBox.currentText().lower()
        smoothing = self.cloudsProcessing_exportFinalSmoothing_comboBox.currentText().lower()

        self.cloudsProcessing_log_textBrowser.append(f"Saving cloud. Method: {method}, resolution: {resolution}, smoothing: {smoothing}")

        if resolution == "low":
            poisson_depth = 6
            ball_pivoting_radii = [0.005, 0.01, 0.02]
            alpha_value = 0.03
        elif resolution == "average":
            poisson_depth = 8
            ball_pivoting_radii = [0.01, 0.02, 0.04]
            alpha_value = 0.05
        else:
            poisson_depth = 10
            ball_pivoting_radii = [0.02, 0.04, 0.08]
            alpha_value = 0.1

        mesh = None
        try:
            if method == "poisson":
                mesh, densities = o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(cloud, depth=poisson_depth)
                densities = np.asarray(densities)
                density_threshold = np.percentile(densities, 10)
                mesh = mesh.select_by_index(np.where(densities > density_threshold)[0])
            elif method == "ball-pivot":
                radii = o3d.utility.DoubleVector(ball_pivoting_radii)
                mesh = o3d.geometry.TriangleMesh.create_from_point_cloud_ball_pivoting(cloud, radii)
            elif method == "alpha-shapes":
                tetra_mesh, pt_map = o3d.geometry.TetraMesh.create_from_point_cloud(cloud)
                mesh = o3d.geometry.TriangleMesh.create_from_point_cloud_alpha_shape(cloud, alpha_value, tetra_mesh, pt_map)
            elif method == "delaunay":
                mesh = o3d.geometry.TriangleMesh.create_from_point_cloud_alpha_shape(cloud, alpha_value * 2)
            else:
                self.cloudsProcessing_log_textBrowser.append(f"Method {method} is not supported.")
                return

            if smoothing == "laplacian":
                mesh = mesh.filter_smooth_simple(number_of_iterations=5)
            elif smoothing == "taubin":
                mesh = mesh.filter_smooth_taubin(number_of_iterations=10)

            base_name = self.clouds_tableWidget.item(row, 0).text()
            file_stem = os.path.join(dir_path, f"{base_name}_mesh")

            o3d.io.write_triangle_mesh(file_stem + self.cloudsProcessing_saveFormat_comboBox.itemText(), mesh)

            self.cloudsProcessing_log_textBrowser.append(f"Mesh saved: {self.cloudsProcessing_saveFormat_comboBox.itemText()}")
        except Exception as e:
            self.cloudsProcessing_log_textBrowser.append(f"Save error: {e}")

if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    window = MyForm()
    window.resize(630, 680)
    window.show()
    sys.exit(app.exec())
