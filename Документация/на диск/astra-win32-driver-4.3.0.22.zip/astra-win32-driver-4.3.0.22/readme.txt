Double click SensorDriver_Vx.x.x.x.exe to start driver installation.
Please re-plug the camera and reboot the computer after installation.